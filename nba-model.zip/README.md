# NBA Projection Engine

Live Monte Carlo NBA projections.

## Deploy on Render

1. Create a new Web Service on Render
2. Connect this repo
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `streamlit run app.py --server.port $PORT --server.address 0.0.0.0`
